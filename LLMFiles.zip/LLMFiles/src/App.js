import React, {Component, useState, useEffect} from 'react';
import {Button, Col, Row, Navbar, Nav, ButtonGroup, Modal, Container} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
    Routes,
    Route
} from "react-router-dom";
import LoadingScreen from './LoadingScreen';
import EssayWriter from './EssayWriter';
import axios from 'axios';

function App() {
  const {test, setTest} = useState(0);
  return (
    <div>
      <Routes>
        <Route path="/test" element={<p>{test}??</p>} />
        <Route exact path="/" element={<LoadingScreen />} />
        <Route path="/essay" element={<EssayWriter />} />
      </Routes>      
  </div>
  );
}

export default App;
