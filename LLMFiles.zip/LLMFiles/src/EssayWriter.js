import React, {useState, useRef, memo} from 'react';
import {Button, Form, Modal, Row} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { motion } from "framer-motion"
import io from 'socket.io-client';
import Typewriter from "./typewriter";
import Snowfall from 'react-snowfall'


export default function EssayHelper() {
  const [answer, setAnswer] = useState("Ask me a question!")
  const [settingModal, setSettingModal] = useState(false)
  const [typewriterSpeed, setTypewriterSpeed] = useState(20)
  const [pickColor, setPickColor] = useState("blue")
  const inputText = useRef("");
  const socket = io("http://127.0.0.1:5000");
  const openModal = () => setSettingModal(true);
  const closeModal = () => setSettingModal(false);
  const changeDelay = (event) => setTypewriterSpeed(event.target.value);


  const CurrentText = memo(({text, delay}) => {
      return (<p><strong><Typewriter text={text} delay={delay} /></strong></p>)
  });

  const send = async () => {  
    loading()
    await socket.emit("message", {"value": {inputText}})
    // gets result
    await fetch("http://127.0.0.1:5000")
    .then(response => response.json())  
    .then(json => {
        // Formats string
        let string = JSON.stringify(json["result"])
        setAnswer(string.substring(1, string.length-1))
    })
    
  }
  const loading = () => {
    setAnswer("Loading... Please wait patiently...")
  }

  const handleChange = (event) => {
    inputText.current = event.target.value;
  }
  const changeColor = (event) => {
    setPickColor(event.target.value);
  }

  const handleKeyPress = (target) => {
    if (target.charCode===13) {
      send()
    }
  } 
    
  
	return (
  <body style={{
        backgroundColor: pickColor, backgroundRepeat: "no-repeat", backgroundSize: "cover", height: "100vh"}}>
  <div>
  <motion.div
    initial={{ y: -1000 }}
    animate={{ y: 0}}
    transition={{ duration: 1.5, ease: "easeInOut" }}
  >
	<div id="essay">
	  <style type="text/css"> {`
	  #body {
	  	height: 100%;
	  	margin: 0;
	  	background-color: blue;
      background-repeat: no-repeat;
      background-size: cover;
	  }
    input {
      margin-top: 50px;
    }

    .text-to-fade-in {
      text-align: center;
      margin-top: 60px;
      animation: typing 4s;
      color: white;
    }
    p {
      color: black;
      font-family: Garamond;
    }
    #disclaimer {
      margin-top: 40px;
      margin-left: 150px;
      color: white;
    }
    
    #textPart {
      width: 80%;
      margin-left: 150px;
      margin-right: 100px;
      display: inline-block;
    }
    #button {
      display: inline-block;
    }
    #bot_answer {
      margin: 150px 100px;
      margin-top: 50px;
      padding: 30px;
      border: 1px solid #000;
      background-color: gray;
    }
    #formElements {
      width: 20%;
      margin-left: 20px;
      margin-bottom: 30px;

    }
    #dropdown {
      width: 20.3%;
      margin-left: 20px;
      margin-bottom: 10px;
    }
	  `}
	    </style>
	 <div id="textPart">
      <div id="headerPart">
        <h3 class="text-to-fade-in">Type in your prompt below!</h3>   
      </div>
        <p id="disclaimer"><strong>Disclaimer: </strong><i>ChatTSA is an experimental bot and can often bring up irrelevant data</i></p>
      <Modal show={settingModal} onHide={closeModal} size="xl">
        <Modal.Header>
                <Modal.Title>
                <p><strong>Settings</strong></p>
                
                </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>  
              <Form.Group>
              <Row>
              <Form.Label>Typewriter Delay: </Form.Label> 
              <Form.Control
                id="formElements"
                placeholder={typewriterSpeed} 
                maxLength="2"
                onChange={changeDelay}
                />
                </Row>
                <Row>
                <Form.Label>Background Color: </Form.Label> 
                <Form.Select 
                    aria-label="Color"
                    onChange={changeColor}
                    id="dropdown"
                  >
                  <option>Default</option>
                  <option value="#000000">Black</option>
                  <option value="#7a7a7a">Grey</option>
                  <option value="#00008B">Dark Blue</option>
                  <option value="#008080">Teal</option>
                  <option value="#ffe135">Yellow</option>
                  <option value="#e14848">Red</option>
                  <option value="#c10ee9">Purple</option>
                  <option value="#05650e">Green</option>
                </Form.Select>
                </Row>
              </Form.Group>
            </Form>

          </Modal.Body>
          <Modal.Footer>
          <Button variant="success" name="open" id="submitSettings" onClick={closeModal}>Go!</Button>
          </Modal.Footer>
       </Modal>
        <Form onSubmit={(e) => {e.preventDefault()}}>
      <Form.Group className="mb-3" controlId="Essay">
        <Form.Control 
          type="textarea" 
          placeholder="Type here!" 
          value={inputText.current.value}
          onChange={handleChange}
          onKeyPress={handleKeyPress}
          onSubmit={(e) => {e.preventDefault()}}
          />
      </Form.Group>
      <Button variant="primary" id="button" onClick={send}>
      Submit
      </Button>
      <Button variant="secondary" id="settings" onClick={openModal} name="open">
      Settings
      </Button>
      </Form>
      <div id="bot_answer"><CurrentText text={answer} delay={typewriterSpeed}/></div>
    </div>
	  </div>
    </motion.div>
    </div>
    </body>
		)
}
