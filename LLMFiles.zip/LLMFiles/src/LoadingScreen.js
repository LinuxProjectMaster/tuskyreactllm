import React, {Component, useState, useEffect} from 'react';
import {Button, Modal, Container} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { motion } from "framer-motion"
import Snowfall from 'react-snowfall'


function LoadingScreen(){
	class SettingModal extends Component {
		constructor(props) {
			super(props);
			this.state = {
				openModal: false
			}

			this.handleEvent = this.handleEvent.bind(this)
		}

		handleEvent() {
			this.setState({openModal: !this.state.openModal})

		}

	 render() {
	 	return (
	 		<div id="everything">
	 		<div id="settings">
      	<motion.div initial={{ opacity: 0, y:-50}} animate={{ opacity: 1, y: 0}} transition={{duration: 0.5, delay: 1}} viewport={{ once: true }}>
   		  <Button variant="danger" size="lg" onClick={this.handleEvent}>Credits</Button>
   		</motion.div>
   		</div>
	 		<div id="loadingModal">
	 		<Modal show={this.state.openModal} onHide={this.handleEvent}>
   		  		<Modal.Header>
   		  			<Modal.Title>
   		  				Credits:
   		  				
   		  			</Modal.Title>
   		  		</Modal.Header>
   		  		<Modal.Body>
   		  			<strong>Collaborators: </strong>
   		  			<div id="surrounding">
   		  				<i><span>Colin Weisman</span>
   		  				<span>Isiah Williams</span>
   		  				<span>Jacob Jackson</span>
   		  				<span>Aly Gold</span>
   		  				<span>Quinn Faye</span>
   							<span>Sean Walker</span></i>

   		  				</div>
   		  			</Modal.Body>
   		  			<Modal.Footer>
   		  			<p>Thank you for helping with TSA!</p>
   		  			</Modal.Footer>
   		 </Modal>


	 		</div>
	 		</div>
	 		)
	 }
	}

	class HeaderApp extends Component {
    render() {
      return (
      <div id="Header">
    	<head>
      		<style type="text/css">
      			{`
        .text-centered {
          text-align: center;
          margin-top: 20px;
          font-family: Garamond;
          color: white;
        }
        #startButton, #settings {
          margin-top: 100px;
          font-family: Garamond;
          text-align: center;

        }
        #surrounding {
        	border: 1px solid #000;
        	border-radius: 25px;
        	padding: 30px;
        	margin-top: 30px;
        	background-color: #ADD8E6;
        }
        a {
          color: rgb(0, 0, 0);
          text-decoration: none;
        }
        .spreadOut {
        	margin: 50px;
        }
        .spreadOutTiny {
        	margin: 20px;
        }
        span {
        	display: flex;
        }


      `}
        </style>
      	</head>
    <body>
    <Container fluid>
      <h1 class="text-centered">Tuscarora Student Answers</h1>
	</Container>
    </body>
   </div>    
      );
    }
  }
   class StartButton extends Component {
   	constructor(props) {
   		super(props);
   	}
   	render() {
   		return (
   		<div id="startButton">
   			<motion.div 
   					initial={{ opacity: 0, y:-50}} 
   					animate={{ opacity: 1, y: 0}} 
   					transition={{duration: 0.5}}
   					whileInView="visible" 
   					viewport={{ once: true }}

   					>
   			  <a className="btn btn-success btn-lg" href="#/essay">Start</a>
   			 </motion.div>  			
   		</div>
   			)
   	}

   }

	return (
		<div>
		<body>
			<Snowfall />
		  <HeaderApp />
		  <StartButton />
		  <SettingModal />
		  <style type="text/css">
		  		{`
		  		body {
		  			height: 100%;
		  			background-image: url(https://images.alphacoders.com/134/1348846.png);
		  			background-repeat: no-repeat;
		  			background-size: cover;
		  		}

		  		`}
			</style>
			</body>
		</div>
		)
}
	
export default LoadingScreen;